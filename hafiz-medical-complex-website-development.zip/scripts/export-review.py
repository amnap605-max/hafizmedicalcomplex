#!/usr/bin/env python3
"""Export the live Next.js site as safe, navigable static client-review ZIPs.

The production application remains the source of truth. These snapshots intentionally
have no patient-data backend and make that limitation visible to visitors.
"""
from __future__ import annotations

import html as html_lib
import json
import re
import subprocess
import urllib.parse
import urllib.request
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
ORIGIN = "http://127.0.0.1:3000"


def get(path: str) -> bytes:
    request = urllib.request.Request(ORIGIN + path, headers={"User-Agent": "HMCReviewExporter/1.0"})
    with urllib.request.urlopen(request, timeout=40) as response:
        if response.status != 200:
            raise RuntimeError(f"Unexpected response for {path}: {response.status}")
        return response.read()


def content_data() -> dict:
    node_script = r"""
const ts=require('typescript'),fs=require('fs');
const source=fs.readFileSync('src/lib/content.ts','utf8');
const output=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
const m={exports:{}};new Function('exports','module','require',output)(m.exports,m,require);
console.log(JSON.stringify({doctors:m.exports.doctors,specialties:m.exports.specialties}));
"""
    result = subprocess.check_output(["node", "-e", node_script], cwd=ROOT, text=True)
    return json.loads(result)


def filename(path: str) -> str:
    return "index.html" if path == "/" else path.strip("/").replace("/", "--") + ".html"


def clean_html(source: str, route_files: dict[str, str], variant: str) -> str:
    source = re.sub(r"<script\b[^>]*>.*?</script\s*>", "", source, flags=re.I | re.S)
    source = re.sub(r"<link\b[^>]*rel=\"(?:stylesheet|preload|modulepreload)\"[^>]*>", "", source, flags=re.I)
    source = re.sub(r"<link\b[^>]*rel=\"canonical\"[^>]*>", "", source, flags=re.I)
    source = re.sub(r"\s+srcset=\"[^\"]*\"", "", source, flags=re.I)
    source = re.sub(r"\s+imagesrcset=\"[^\"]*\"", "", source, flags=re.I)

    def image_source(match: re.Match[str]) -> str:
        url = html_lib.unescape(match.group(1))
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        original = query.get("url", [url])[0]
        return f'src="{html_lib.escape(original, quote=True)}"'

    source = re.sub(r'src="(/_next/image\?[^\"]+)"', image_source, source, flags=re.I)
    source = re.sub(r'<a\b([^>]*?)href="/admin"([^>]*)>Staff access</a>', '<span>Staff access on the live application</span>', source, flags=re.I)

    def internal_link(match: re.Match[str]) -> str:
        raw = html_lib.unescape(match.group(1))
        parsed = urllib.parse.urlsplit(raw)
        if parsed.path not in route_files:
            return match.group(0)
        target = "/" if parsed.path == "/" else "/" + route_files[parsed.path]
        if parsed.query:
            target += "?" + parsed.query
        if parsed.fragment:
            target += "#" + parsed.fragment
        return f'href="{html_lib.escape(target, quote=True)}"'

    source = re.sub(r'href="(/[^"]*)"', internal_link, source)
    label = "OPTION A · CLASSIC BLUE" if variant == "classic" else "OPTION B · TEAL REDESIGN"
    theme_script = f"(function(){{document.documentElement.setAttribute('data-demo-theme','{variant}');document.documentElement.setAttribute('data-preview-variant','{variant}')}})();"
    head = (
        '<meta name="robots" content="noindex,nofollow">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<link rel="stylesheet" href="/demo.css">'
        f'<script>{theme_script}</script>'
    )
    source = source.replace("<head>", "<head>" + head, 1)
    banner = (
        '<div class="review-mode-banner"><div class="container-site">'
        f'<strong>{label}</strong><span>Client design preview · Online forms do not submit here. '
        'For an actual visit, <a href="tel:+923323338726">call the hospital</a> or '
        '<a href="https://wa.me/923323338726" target="_blank" rel="noopener noreferrer">use WhatsApp</a>.</span>'
        '</div></div>'
    )
    source = source.replace('<main id="main-content">', banner + '<main id="main-content">', 1)
    source = source.replace('<form class="form-card">', '<form class="form-card" onsubmit="return false">')
    source = source.replace("</body>", '<script src="/demo-preview.js"></script></body>', 1)
    return source


def main() -> None:
    data = content_data()
    routes = ["/", "/about", "/doctors", "/specialties", "/appointments", "/services", "/gallery", "/patient-guide", "/contact"]
    routes += ["/doctors/" + item["slug"] for item in data["doctors"]]
    routes += ["/specialties/" + item["slug"] for item in data["specialties"]]
    route_files = {route: filename(route) for route in routes}
    page_html: dict[str, str] = {}
    for route in routes:
        page_html[route] = get(route).decode("utf-8")
    css_path = re.search(r'href="(/_next/static/[^\"]+\.css)"', page_html["/"])
    if not css_path:
        raise RuntimeError("Could not find the production stylesheet")
    css = get(css_path.group(1)).decode("utf-8")
    css += """
.review-mode-banner{background:#fff7e8;border-bottom:1px solid #ecd8af;color:#665233;padding:10px 0;font-family:'DM Sans',Arial,sans-serif;font-size:11px;line-height:1.55;position:relative;z-index:2}
.review-mode-banner .container-site{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.review-mode-banner strong{white-space:nowrap;color:#805b28;letter-spacing:.06em;font-size:10px}.review-mode-banner a{text-decoration:underline;color:#795318;font-weight:700}
html[data-demo-theme="classic"] .review-mode-banner{background:#f2f8fc;border-bottom-color:#dce9f2;color:#536f87}html[data-demo-theme="classic"] .review-mode-banner strong,html[data-demo-theme="classic"] .review-mode-banner a{color:#2378b8}
.demo-form-feedback{background:#fff7e8;border:1px solid #efd7ae;border-radius:10px;color:#634d2b;padding:17px 20px;margin:18px 0;font-size:12px;line-height:1.6}.demo-form-feedback strong{display:block;font-size:14px;color:#624923}.demo-form-feedback p{margin:7px 0}.demo-form-feedback a{display:inline-flex;margin-top:8px;background:#087f78;color:white;padding:10px 14px;border-radius:8px;font-weight:700}
html[data-preview-variant] body::after{display:none!important}
@media(max-width:700px){.review-mode-banner{font-size:10px}.review-mode-banner .container-site{gap:3px}.review-mode-banner strong{display:block;width:100%}}
"""
    assets = sorted((ROOT / "public/images").glob("*"))
    runtime = (ROOT / "scripts/static-review.js").read_bytes()
    output_paths: list[Path] = []
    for variant in ("classic", "teal"):
        archive = Path(f"/tmp/hmc-{variant}-client-review.zip")
        with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=7) as zip_file:
            for route, markup in page_html.items():
                zip_file.writestr(route_files[route], clean_html(markup, route_files, variant))
            zip_file.writestr("demo.css", css)
            zip_file.writestr("demo-preview.js", runtime)
            zip_file.writestr("demo-data.json", json.dumps(data, ensure_ascii=False, separators=(",", ":")))
            zip_file.write(ROOT / "public/favicon.svg", "favicon.svg")
            for asset in assets:
                if asset.is_file():
                    zip_file.write(asset, "images/" + asset.name)
        output_paths.append(archive)
        with ZipFile(archive) as z:
            count = len(z.namelist())
            print(f"{variant}: {archive} ({archive.stat().st_size / 1024 / 1024:.2f} MB, {count} files, {len(routes)} pages)")
            assert count <= 200
            assert archive.stat().st_size < 20 * 1024 * 1024
            assert all('/_next/image?' not in z.read(route_files[route]).decode('utf-8') for route in routes)
    print("Static review copies created without environment secrets, patient records or active form submissions.")


if __name__ == "__main__":
    main()
