import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, CalendarDays, Check, ChevronRight, Clock3, MapPin, MessageCircle, Phone, Plus, Star } from "lucide-react";
import { SpecialtyIcon } from "@/components/icons";
import { hospital, phoneToHref, specialties as specialtyDirectory, type Doctor, type FAQ, type SiteSettings, type Specialty } from "@/lib/content";
import { siteUrl } from "@/lib/seo";

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  const all = [{ label: "Home", href: "/" }, ...items];
  const structured = { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: all.map((item, index) => ({ "@type": "ListItem", position: index + 1, name: item.label, item: `${siteUrl}${item.href || ""}` })) };
  return <><nav className="breadcrumbs" aria-label="Breadcrumb"><ol>{all.map((item, index) => <li key={`${item.label}-${index}`}>{index > 0 && <ChevronRight size={13} aria-hidden="true" />}{item.href && index < all.length - 1 ? <Link href={item.href}>{item.label}</Link> : <span aria-current={index === all.length - 1 ? "page" : undefined}>{item.label}</span>}</li>)}</ol></nav><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structured).replace(/</g, "\\u003c") }} /></>;
}

export function PageHero({ eyebrow, title, description, image, imageAlt, breadcrumbs }: { eyebrow: string; title: string; description: string; image?: string; imageAlt?: string; breadcrumbs: { label: string; href?: string }[] }) {
  return <section className={`page-hero ${image ? "page-hero-image" : ""}`}><div className="container-site"><Breadcrumbs items={breadcrumbs} /><div className="page-hero-inner"><div className="page-hero-content"><span className="eyebrow"><span className="eyebrow-dot" /> {eyebrow}</span><h1>{title}</h1><p>{description}</p></div>{image ? <div className="page-hero-photo"><Image src={image} alt={imageAlt || "Illustrative healthcare photography"} fill sizes="(max-width: 800px) 100vw, 40vw" className="object-cover" priority /><span className="absolute right-3 bottom-3 rounded-md bg-[#183D3D]/80 px-2 py-1 text-[9px] text-white">Illustrative image · not the hospital</span></div> : <div className="page-hero-art" aria-hidden="true"><span className="art-ring art-ring-one" /><span className="art-ring art-ring-two" /><span className="art-plus art-plus-one"><Plus size={35} /></span><span className="art-plus art-plus-two"><Plus size={20} /></span><span className="art-center"><Plus size={60} strokeWidth={1.5} /></span></div>}</div></div></section>;
}

export function SectionHeading({ eyebrow, title, description, action, center = false }: { eyebrow: string; title: string; description?: string; action?: { label: string; href: string }; center?: boolean }) {
  return <div className={`section-heading ${center ? "section-heading-center" : ""}`}><div><span className="eyebrow"><span className="eyebrow-dot" /> {eyebrow}</span><h2>{title}</h2>{description && <p>{description}</p>}</div>{action && <Link href={action.href} className="text-link">{action.label} <ArrowUpRight size={18} /></Link>}</div>;
}

export function DoctorAvatar({ doctor, large = false }: { doctor: Doctor; large?: boolean }) {
  return <div className={`doctor-avatar ${large ? "doctor-avatar-large" : ""}`} role="img" aria-label={`Initials placeholder for ${doctor.name}`}>{doctor.image ? <img src={doctor.image} alt={`Portrait of ${doctor.name}`} /> : <><span className="avatar-cross" aria-hidden="true"><Plus size={large ? 35 : 24} strokeWidth={1.3} /></span><span className="avatar-initials">{doctor.initials}</span><span className="avatar-caption">PROFILE PHOTO PENDING</span></>}</div>;
}

export function DoctorCard({ doctor }: { doctor: Doctor }) {
  const careImage = specialtyDirectory.find((item) => doctor.specialtySlugs.includes(item.slug))?.image || "/images/hero-south-asian.jpg";
  return <article className="doctor-card"><div className="doctor-card-scene"><Image src={careImage} alt={`Illustrative South Asian healthcare scene related to ${doctor.specialty}; not a portrait of ${doctor.name}`} fill sizes="(max-width: 700px) 100vw, (max-width: 900px) 50vw, 33vw" className="object-cover" /><span>Illustrative · not this doctor</span></div><div className="doctor-card-content"><div className="doctor-card-top"><DoctorAvatar doctor={doctor} /><div><span className="mini-label">MEET YOUR SPECIALIST</span><h3><Link href={`/doctors/${doctor.slug}`}>{doctor.name}</Link></h3><p className="doctor-specialty">{doctor.specialty}</p></div></div><p className="doctor-summary">{doctor.summary}</p><div className="doctor-schedule"><Clock3 size={17} /><span>{doctor.schedule.label}</span></div><div className="doctor-card-actions"><Link className="card-profile-link" href={`/doctors/${doctor.slug}`}>View Profile <ArrowRight size={16} /></Link><Link className="card-book-link" href={`/appointments?doctor=${doctor.slug}`}>Book Appointment <ArrowUpRight size={15} /></Link></div></div></article>;
}

export function SpecialtyCard({ specialty, index }: { specialty: Specialty; index?: number }) {
  return <Link href={`/specialties/${specialty.slug}`} className="specialty-card"><div className="specialty-card-photo"><Image src={specialty.image} alt={`Illustrative South Asian care scene for ${specialty.title}, not hospital staff or facilities`} fill sizes="(max-width: 700px) 100vw, (max-width: 900px) 50vw, 33vw" className="object-cover" /><span>Illustrative care scene</span></div><div className="specialty-card-body"><span className={`specialty-icon specialty-icon-${(index || 0) % 3}`}><SpecialtyIcon name={specialty.icon} size={25} /></span><span className="specialty-card-number">0{(index || 0) + 1}</span><h3>{specialty.title}</h3><p>{specialty.description}</p><span className="specialty-explore">Explore Specialty <ArrowUpRight size={17} /></span></div></Link>;
}

export function FAQList({ faqs }: { faqs: FAQ[] }) {
  return <div className="faq-list">{faqs.map((faq, index) => <details className="faq-item" key={faq.question} open={index === 0}><summary><span>{faq.question}</span><Plus size={20} aria-hidden="true" /></summary><p>{faq.answer}</p></details>)}</div>;
}

export function CalloutCTA({ title = "Your Health Journey Starts With the Right Care.", description = "Take the next step. Tell us who you would like to see, and our team will help with your appointment request.", button = "Book an Appointment" }: { title?: string; description?: string; button?: string }) {
  return <section className="cta-band"><div className="container-site cta-inner"><div><span className="cta-kicker"><span /> HERE WHEN YOU NEED US</span><h2>{title}</h2><p>{description}</p></div><Link href="/appointments" className="btn btn-white">{button} <ArrowUpRight size={18} /></Link></div><div className="cta-decoration" aria-hidden="true" /></section>;
}

export function MapPanel({ settings, compact = false }: { settings: SiteSettings; compact?: boolean }) {
  const whatsapp = `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent("Hello HAFIZ Medical Complex, I would like to request an appointment.")}`;
  return <div className={`map-panel ${compact ? "map-panel-compact" : ""}`}><div className="map-frame"><iframe src={hospital.mapEmbed} title="Map showing HAFIZ Medical Complex on College Road in Daska" loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen /></div><div className="map-details"><span className="eyebrow"><span className="eyebrow-dot" /> FIND US IN DASKA</span><h3>Care, close to home.</h3><p>Located at Milad Chowk on College Road, with a convenient point of contact for appointment assistance.</p><div className="map-address"><MapPin size={20} /><span>{settings.address}</span></div><div className="map-actions"><a className="btn btn-primary" href={settings.mapUrl} target="_blank" rel="noopener noreferrer">Get Directions <ArrowUpRight size={17} /></a><a className="btn btn-outline" href={phoneToHref(settings.phone)}><Phone size={16} /> Call Hospital</a><a className="map-whatsapp" href={whatsapp} target="_blank" rel="noopener noreferrer"><MessageCircle size={16} /> WhatsApp appointment</a></div></div></div>;
}

export function ReviewStrip({ mapUrl }: { mapUrl: string }) {
  return <div className="review-strip"><div className="review-score"><span className="review-google">G</span><div><span className="review-stars" aria-label="5 out of 5 stars">{Array.from({ length: 5 }, (_, i) => <Star key={i} size={16} fill="currentColor" strokeWidth={0} />)}</span><strong>{hospital.rating} <small>/ 5.0</small></strong></div></div><div className="review-copy"><strong>Rated on Google</strong><span>Based on {hospital.reviewCount} Google reviews, as supplied by the hospital.</span></div><a href={mapUrl} target="_blank" rel="noopener noreferrer" className="text-link">View Google listing <ArrowUpRight size={17} /></a></div>;
}

export function ScheduleNote() {
  return <p className="schedule-note"><CalendarDays size={17} /> Hospital operating hours are separate from individual doctors&apos; consultation schedules. Please confirm availability before visiting.</p>;
}

export function CheckList({ items }: { items: string[] }) {
  return <ul className="check-list">{items.map((item) => <li key={item}><span><Check size={15} /></span>{item}</li>)}</ul>;
}
