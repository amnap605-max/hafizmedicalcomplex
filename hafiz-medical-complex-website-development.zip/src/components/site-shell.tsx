"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowRight, ArrowUpRight, Clock3, Mail, MapPin, Menu, Phone, X } from "lucide-react";
import { BrandMark } from "@/components/icons";
import { FaFacebookF, FaInstagram, FaLinkedinIn, FaTiktok, FaWhatsapp, FaYoutube } from "react-icons/fa6";
import { hospital, phoneToHref, type SiteSettings } from "@/lib/content";

const nav = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Our Doctors", href: "/doctors" },
  { label: "Specialties", href: "/specialties" },
  { label: "Services", href: "/services" },
  { label: "Gallery", href: "/gallery" },
  { label: "Contact", href: "/contact" },
];

function safeExternal(url: string) {
  try { return new URL(url).protocol === "https:" ? url : ""; } catch { return ""; }
}

export function Logo({ light = false }: { light?: boolean }) {
  return <Link href="/" aria-label="HAFIZ Medical Complex home" className="logo-wrap"><BrandMark /><span className="logo-type"><span className={`logo-name ${light ? "text-white" : ""}`}>HAFIZ <span className="font-normal">Medical Complex</span></span><span className={`logo-tagline ${light ? "text-blue-100/75" : ""}`}>QUALITY HEALTHCARE, COMPASSIONATE CARE</span></span></Link>;
}

export function SiteHeader({ settings }: { settings: SiteSettings }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => { setOpen(false); }, [pathname]);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  const instagram = safeExternal(settings.instagram);
  return <header className="site-header">
    <div className="topbar"><div className="container-site topbar-inner">
      <div className="topbar-group"><a href={phoneToHref(settings.phone)}><Phone size={13} /> {settings.phone}</a><span className="topbar-divider" /><span><MapPin size={13} /> Daska, Pakistan</span></div>
      <div className="topbar-group"><span><Clock3 size={13} /> Hospital open 24 hours <span className="topbar-extra">· Doctor hours vary</span></span>{instagram && <a href={instagram} target="_blank" rel="noopener noreferrer" aria-label="HAFIZ Medical Complex on Instagram"><FaInstagram size={15} /></a>}</div>
    </div></div>
    <div className="container-site nav-inner">
      <Logo />
      <nav className="desktop-nav" aria-label="Primary navigation">{nav.map((item) => <Link key={item.href} href={item.href} className={(item.href === "/" ? pathname === "/" : pathname.startsWith(item.href)) ? "nav-link active" : "nav-link"}>{item.label}</Link>)}</nav>
      <Link href="/appointments" className="btn btn-primary header-cta">Book Appointment <ArrowUpRight size={16} /></Link>
      <button type="button" className="menu-toggle" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(!open)}>{open ? <X size={25} /> : <Menu size={25} />}</button>
    </div>
    {open && <nav id="mobile-menu" className="mobile-menu" aria-label="Mobile navigation"><div className="container-site">{nav.map((item) => <Link key={item.href} href={item.href} className={`mobile-link ${(item.href === "/" ? pathname === "/" : pathname.startsWith(item.href)) ? "active" : ""}`} onClick={() => setOpen(false)}>{item.label}<ArrowRight size={16} /></Link>)}<Link href="/patient-guide" className="mobile-link" onClick={() => setOpen(false)}>Patient Guide & FAQs <ArrowRight size={16} /></Link><Link href="/appointments" className="btn btn-primary mobile-book" onClick={() => setOpen(false)}>Book an Appointment <ArrowUpRight size={16} /></Link></div></nav>}
  </header>;
}

export function SiteFooter({ settings }: { settings: SiteSettings }) {
  const socialLinks = [
    { label: "Instagram", href: settings.instagram, Icon: FaInstagram },
    { label: "Facebook", href: settings.facebook, Icon: FaFacebookF },
    { label: "YouTube", href: settings.youtube, Icon: FaYoutube },
    { label: "TikTok", href: settings.tiktok, Icon: FaTiktok },
    { label: "LinkedIn", href: settings.linkedin, Icon: FaLinkedinIn },
  ].filter((link) => safeExternal(link.href));
  const whatsapp = `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent("Hello HAFIZ Medical Complex, I would like to request an appointment.")}`;
  return <footer className="site-footer"><div className="container-site">
    <div className="footer-main">
      <div className="footer-brand"><Logo light /><p>Accessible specialist consultations and patient-focused healthcare in the heart of Daska.</p><p className="!mt-[-10px] !mb-5 !text-[10px] !leading-5 !text-[#b9d3c7]">Website care imagery is illustrative, not photographs of hospital staff or premises.</p><div className="footer-social">{socialLinks.map(({ label, href, Icon }) => <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={`Visit HAFIZ Medical Complex on ${label}`}><Icon size={17} /></a>)}</div></div>
      <div><h3>Explore</h3><div className="footer-links"><Link href="/about">About the Hospital</Link><Link href="/doctors">Find a Doctor</Link><Link href="/specialties">Medical Specialties</Link><Link href="/services">Services & Facilities</Link><Link href="/gallery">Gallery</Link></div></div>
      <div><h3>Patient Support</h3><div className="footer-links"><Link href="/appointments">Request an Appointment</Link><Link href="/patient-guide">Patient Guide & FAQs</Link><Link href="/contact">Contact Us</Link><a href={settings.mapUrl} target="_blank" rel="noopener noreferrer">Get Directions <ArrowUpRight size={13} /></a></div></div>
      <div className="footer-contact"><h3>Get in touch</h3><a href={phoneToHref(settings.phone)}><Phone size={17} /> {settings.phone}</a><a href={`mailto:${settings.email}`}><Mail size={17} /> {settings.email}</a><p><MapPin size={18} /> <span>{settings.address}</span></p><p className="footer-hours"><Clock3 size={17} /><span>Hospital open 24 hours.<br /><small>Doctor consultation hours vary; confirm before visiting.</small></span></p></div>
    </div>
    <div className="footer-bottom"><span>© {new Date().getFullYear()} {hospital.name}. All rights reserved.</span><span>Made for the Daska community <span className="footer-dot">·</span> <Link href="/admin">Staff access</Link></span></div>
  </div><MobileActionBar settings={settings} whatsapp={whatsapp} /></footer>;
}

function MobileActionBar({ settings, whatsapp }: { settings: SiteSettings; whatsapp: string }) {
  return <div className="mobile-actions"><a href={phoneToHref(settings.phone)}><Phone size={18} /> Call Hospital</a><a href={whatsapp} target="_blank" rel="noopener noreferrer"><FaWhatsapp size={19} /> WhatsApp</a></div>;
}
