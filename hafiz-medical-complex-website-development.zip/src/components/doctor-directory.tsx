"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowUpRight, CalendarDays, Search, Stethoscope } from "lucide-react";
import { DoctorCard } from "@/components/ui";
import { weekdayOptions, type Doctor, type Specialty } from "@/lib/content";

export function DoctorDirectory({ doctors, specialties, preview = false }: { doctors: Doctor[]; specialties: Specialty[]; preview?: boolean }) {
  const [query, setQuery] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [day, setDay] = useState("");
  const filtered = useMemo(() => doctors.filter((doctor) => {
    const q = query.trim().toLowerCase();
    const matchesText = !q || `${doctor.name} ${doctor.specialty} ${doctor.summary} ${doctor.alsoKnownAs || ""}`.toLowerCase().includes(q);
    const matchesSpecialty = !specialty || doctor.specialtySlugs.includes(specialty);
    const matchesDay = !day || (day === "unconfirmed" ? !doctor.schedule.confirmed : doctor.schedule.days.includes(Number(day)));
    return matchesText && matchesSpecialty && matchesDay;
  }), [doctors, query, specialty, day]);
  const visible = preview ? filtered.slice(0, 3) : filtered;
  return <div><div className="directory-toolbar">
    <label className="directory-field"><span className="sr-only">Search doctors by name or specialty</span><Search size={17} /><input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search doctor or specialty..." /></label>
    <label className="directory-field"><span className="sr-only">Filter by specialty</span><Stethoscope size={17} /><select value={specialty} onChange={(event) => setSpecialty(event.target.value)}><option value="">All specialties</option>{specialties.map((item) => <option key={item.slug} value={item.slug}>{item.shortTitle}</option>)}</select></label>
    <label className="directory-field"><span className="sr-only">Filter by visiting day</span><CalendarDays size={17} /><select value={day} onChange={(event) => setDay(event.target.value)}><option value="">Any visiting day</option>{weekdayOptions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}<option value="unconfirmed">Schedule to confirm</option></select></label>
  </div><p className="directory-results">{filtered.length} {filtered.length === 1 ? "doctor" : "doctors"} match your search{preview && filtered.length > 3 ? " · showing the first 3" : ""}.</p>
    {visible.length ? <div className="doctor-grid">{visible.map((doctor) => <DoctorCard key={doctor.slug} doctor={doctor} />)}</div> : <div className="empty-state"><Search size={26} /><h3>No matching doctors found</h3><p>Try another name, specialty or visiting day, or call the hospital for help.</p></div>}
    {preview && <div className="directory-bottom"><Link href="/doctors" className="btn btn-outline">View All Doctors <ArrowUpRight size={17} /></Link></div>}
  </div>;
}

export function QuickAppointment({ doctors, specialties }: { doctors: Doctor[]; specialties: Specialty[] }) {
  const router = useRouter();
  const [specialty, setSpecialty] = useState("");
  const [doctor, setDoctor] = useState("");
  const relevant = specialty ? doctors.filter((item) => item.specialtySlugs.includes(specialty)) : doctors;
  const go = () => {
    const params = new URLSearchParams();
    if (specialty) params.set("specialty", specialty);
    if (doctor) params.set("doctor", doctor);
    router.push(`/appointments${params.size ? `?${params.toString()}` : ""}`);
  };
  return <div className="quick-wrap container-site"><div className="quick-card"><div className="quick-intro"><span>NEED TO SEE A SPECIALIST?</span><strong>Let&apos;s find the right care.</strong></div><div className="quick-field"><label htmlFor="quick-specialty">Medical specialty</label><select id="quick-specialty" value={specialty} onChange={(event) => { setSpecialty(event.target.value); setDoctor(""); }}><option value="">Choose a specialty</option>{specialties.map((item) => <option key={item.slug} value={item.slug}>{item.shortTitle}</option>)}</select></div><div className="quick-field"><label htmlFor="quick-doctor">Preferred doctor</label><select id="quick-doctor" value={doctor} onChange={(event) => setDoctor(event.target.value)}><option value="">Choose a doctor</option>{relevant.map((item) => <option key={item.slug} value={item.slug}>{item.name}</option>)}</select></div><button type="button" className="btn btn-primary" onClick={go}>Request Visit <ArrowUpRight size={16} /></button></div><p className="quick-note">Appointment requests are reviewed by hospital staff. Visiting hours vary by doctor.</p></div>;
}
