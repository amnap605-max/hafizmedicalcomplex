"use client";

import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Expand, X } from "lucide-react";
import type { GalleryEntry } from "@/lib/content";

const categories = ["All Photos", "Hospital Exterior", "Hospital Interior", "Doctors", "Medical Team", "Patient Care", "Facilities"];

export function GalleryGrid({ items }: { items: GalleryEntry[] }) {
  const [category, setCategory] = useState("All Photos");
  const [selected, setSelected] = useState<number | null>(null);
  const filtered = useMemo(() => items.filter((item) => item.published && (category === "All Photos" || item.category === category)), [items, category]);
  useEffect(() => {
    if (selected === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelected(null);
      if (event.key === "ArrowRight") setSelected((index) => index === null ? null : (index + 1) % filtered.length);
      if (event.key === "ArrowLeft") setSelected((index) => index === null ? null : (index - 1 + filtered.length) % filtered.length);
    };
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = original; window.removeEventListener("keydown", onKey); };
  }, [selected, filtered.length]);
  const current = selected !== null ? filtered[selected] : null;
  return <><div className="filter-pills" role="group" aria-label="Filter gallery photographs">{categories.map((item) => <button key={item} type="button" className={`filter-pill ${category === item ? "active" : ""}`} aria-pressed={category === item} onClick={() => { setCategory(item); setSelected(null); }}>{item}</button>)}</div>
    {filtered.length ? <div className="gallery-grid">{filtered.map((item, index) => <button key={item.id} type="button" className="gallery-item" onClick={() => setSelected(index)} aria-label={`View larger image: ${item.title}`}><div className="gallery-image"><img src={item.image} alt={item.alt} loading="lazy" /><span className="gallery-expand"><Expand size={15} /></span></div><div className="gallery-info"><span>{item.category}</span><h3>{item.title}</h3><p>{item.placeholder ? "Illustrative placeholder · not a photograph of this hospital" : "Hospital-provided photograph"}</p></div></button>)}</div> : <div className="empty-state"><h3>No photographs in this category yet.</h3><p>Hospital management can add verified imagery through the staff dashboard.</p></div>}
    {current && <div className="lightbox-backdrop" role="presentation" onClick={() => setSelected(null)}><div role="dialog" aria-modal="true" aria-label={current.title} className="lightbox-content" onClick={(event) => event.stopPropagation()}><img src={current.image} alt={current.alt} /><p>{current.title}</p><small>{current.placeholder ? "Illustrative placeholder. This is not the hospital, its staff or its facilities." : "Hospital-provided photograph"}</small></div><button type="button" className="lightbox-close" onClick={() => setSelected(null)} aria-label="Close image"><X size={20} /></button>{filtered.length > 1 && <><button type="button" className="lightbox-prev" onClick={(event) => { event.stopPropagation(); setSelected((index) => index === null ? null : (index - 1 + filtered.length) % filtered.length); }} aria-label="Previous image"><ChevronLeft size={22} /></button><button type="button" className="lightbox-next" onClick={(event) => { event.stopPropagation(); setSelected((index) => index === null ? null : (index + 1) % filtered.length); }} aria-label="Next image"><ChevronRight size={22} /></button></>}</div>}
  </>;
}
