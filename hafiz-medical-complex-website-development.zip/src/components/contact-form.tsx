"use client";

import { useState, type FormEvent } from "react";
import { ArrowUpRight, Check, Mail, Phone } from "lucide-react";
import type { SiteSettings } from "@/lib/content";
import { phoneToHref } from "@/lib/content";

export function ContactForm({ settings }: { settings: SiteSettings }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "", website: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const update = (field: keyof typeof form, value: string) => { setForm((current) => ({ ...current, [field]: value })); setError(""); };
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const data = await response.json();
      if (!response.ok) { setError(data.error || "Could not send your message. Please try again."); return; }
      setSent(true);
    } catch { setError("Connection problem. Please call or email the hospital instead."); }
    finally { setBusy(false); }
  }
  if (sent) return <div className="success-panel" role="status" aria-live="polite"><span className="success-icon"><Check size={28} /></span><h2>Thank you for getting in touch.</h2><p>Your enquiry has been saved for the hospital team to review. For an appointment request or an immediate question, please contact the hospital directly.</p><div className="success-actions"><a href={phoneToHref(settings.phone)} className="btn btn-primary"><Phone size={16} /> Call Hospital</a><a href={`mailto:${settings.email}`} className="btn btn-outline"><Mail size={16} /> Email Hospital</a></div></div>;
  return <form className="form-card" onSubmit={submit}><h2>Send us a message</h2><p>Have a question about doctors, visiting hours or a service? Send an enquiry and the hospital team can review it.</p><div className="form-grid"><div className="form-group"><label className="form-label" htmlFor="contact-name">Full name <span>*</span></label><input className="form-input" id="contact-name" name="name" autoComplete="name" placeholder="Your full name" minLength={2} maxLength={160} required value={form.name} onChange={(event) => update("name", event.target.value)} /></div><div className="form-group"><label className="form-label" htmlFor="contact-email">Email address <span>*</span></label><input className="form-input" id="contact-email" name="email" autoComplete="email" type="email" placeholder="you@example.com" required value={form.email} onChange={(event) => update("email", event.target.value)} /></div><div className="form-group"><label className="form-label" htmlFor="contact-phone">Phone number <span>*</span></label><input className="form-input" id="contact-phone" name="phone" autoComplete="tel" type="tel" placeholder="03XX XXXXXXX" minLength={9} required value={form.phone} onChange={(event) => update("phone", event.target.value)} /></div><div className="form-group"><label className="form-label" htmlFor="contact-subject">Subject <span>*</span></label><input className="form-input" id="contact-subject" name="subject" placeholder="How can we help?" minLength={3} maxLength={200} required value={form.subject} onChange={(event) => update("subject", event.target.value)} /></div><div className="form-group form-group-full"><label className="form-label" htmlFor="contact-message">Your message <span>*</span></label><textarea className="form-input form-textarea" id="contact-message" name="message" placeholder="Please share your question. Avoid including sensitive medical records." minLength={10} maxLength={3000} required value={form.message} onChange={(event) => update("message", event.target.value)} /></div><div className="honeypot" aria-hidden="true"><label htmlFor="contact-website">Website</label><input id="contact-website" name="website" tabIndex={-1} autoComplete="off" value={form.website} onChange={(event) => update("website", event.target.value)} /></div></div>{error && <div className="form-alert" role="alert">{error}</div>}<div className="form-submit-row"><p className="form-note">For appointment requests, use the booking page. Please do not send sensitive medical information through this form.</p><button type="submit" disabled={busy} className="btn btn-primary">{busy ? "Sending..." : "Send Enquiry"} <ArrowUpRight size={16} /></button></div></form>;
}
