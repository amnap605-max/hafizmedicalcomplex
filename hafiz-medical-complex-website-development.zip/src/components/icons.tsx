import { Activity, AudioLines, BrainCircuit, Droplets, Ear, Heart, HeartPulse, ScanLine, Sparkles, Stethoscope, type LucideIcon } from "lucide-react";

const specialtyIcons: Record<string, LucideIcon> = {
  stethoscope: Stethoscope,
  activity: Activity,
  droplets: Droplets,
  heart: Heart,
  scan: ScanLine,
  sparkles: Sparkles,
  ear: Ear,
  audio: AudioLines,
  brain: BrainCircuit,
};

export function SpecialtyIcon({ name, size = 26, className = "" }: { name: string; size?: number; className?: string }) {
  const Icon = specialtyIcons[name] || HeartPulse;
  return <Icon size={size} strokeWidth={1.8} className={className} aria-hidden="true" />;
}

export function BrandMark({ small = false }: { small?: boolean }) {
  return <span className={`brand-mark ${small ? "brand-mark-small" : ""}`} aria-hidden="true"><HeartPulse size={small ? 21 : 26} strokeWidth={2.3} /></span>;
}
