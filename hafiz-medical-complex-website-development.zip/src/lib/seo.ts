import type { Metadata } from "next";
import { hospital, type Doctor, type SiteSettings } from "@/lib/content";

export const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://localhost:3000")).replace(/\/$/, "");

export function pageMetadata(title: string, description: string, path: string): Metadata {
  return {
    title: { absolute: title === "Home" ? "HAFIZ Medical Complex | Specialist Healthcare in Daska" : `${title} | HAFIZ Medical Complex Daska` },
    description,
    alternates: { canonical: path },
    openGraph: { title: title === "Home" ? "HAFIZ Medical Complex | Daska" : `${title} | HAFIZ Medical Complex`, description, url: `${siteUrl}${path}`, siteName: hospital.name, type: "website", images: [{ url: `${siteUrl}/images/team-south-asian.jpg`, width: 1536, height: 1024, alt: "Illustrative South Asian healthcare team" }] },
    twitter: { card: "summary_large_image", title: `${title} | HAFIZ Medical Complex`, description },
  };
}

export function clinicStructuredData(settings: SiteSettings) {
  const socials = [settings.instagram, settings.facebook, settings.youtube, settings.tiktok, settings.linkedin].filter((url) => {
    try { return new URL(url).protocol === "https:"; } catch { return false; }
  });
  return {
    "@context": "https://schema.org",
    "@type": "MedicalClinic",
    "@id": `${siteUrl}/#medicalclinic`,
    name: hospital.name,
    description: "Multi-specialty healthcare and specialist consultations in Daska, Punjab, Pakistan.",
    url: siteUrl,
    telephone: settings.phone,
    email: settings.email,
    address: { "@type": "PostalAddress", streetAddress: "Milad Chowk, College Road", addressLocality: "Daska", addressRegion: "Punjab", postalCode: "51010", addressCountry: "PK" },
    geo: { "@type": "GeoCoordinates", latitude: 32.332399, longitude: 74.354545 },
    hasMap: settings.mapUrl,
    openingHoursSpecification: [{ "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], opens: "00:00", closes: "23:59" }],
    aggregateRating: { "@type": "AggregateRating", ratingValue: "5.0", reviewCount: 33, bestRating: "5" },
    sameAs: socials,
  };
}

export function doctorStructuredData(doctor: Doctor) {
  if (doctor.slug === "consultant-psychiatrist") return null;
  return {
    "@context": "https://schema.org",
    "@type": doctor.slug === "hammad-raza-mustafai" ? "Person" : "Physician",
    name: doctor.name,
    url: `${siteUrl}/doctors/${doctor.slug}`,
    description: doctor.summary,
    medicalSpecialty: doctor.specialty,
    ...(doctor.qualification ? { hasCredential: doctor.qualification } : {}),
    worksFor: { "@id": `${siteUrl}/#medicalclinic` },
  };
}
