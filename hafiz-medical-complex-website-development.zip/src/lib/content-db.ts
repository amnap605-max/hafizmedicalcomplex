import { db } from "@/db";
import { contentOverrides } from "@/db/schema";
import { eq, like } from "drizzle-orm";
import { defaultSettings, doctors, gallery, services, specialties, type Doctor, type GalleryEntry, type ServiceEntry, type SiteSettings, type Specialty } from "@/lib/content";

async function loadGroup(prefix: string) {
  try {
    return await db.select().from(contentOverrides).where(like(contentOverrides.key, `${prefix}:%`));
  } catch {
    return [];
  }
}

function mergeById<T extends { slug?: string; id?: string }>(defaults: T[], records: { key: string; value: Record<string, unknown> }[], prefix: string) {
  const saved = new Map(records.map((record) => [record.key.replace(`${prefix}:`, ""), record.value]));
  const merged = defaults.map((entry) => {
    const key = entry.slug || entry.id || "";
    return { ...entry, ...(saved.get(key) || {}) } as T;
  });
  for (const [key, value] of saved) {
    if (!defaults.some((entry) => (entry.slug || entry.id) === key) && (value.slug || value.id)) {
      merged.push(value as T);
    }
  }
  return merged;
}

export async function getDoctors(): Promise<Doctor[]> {
  const records = await loadGroup("doctor");
  const base = doctors.map((doctor) => {
    const override = records.find((record) => record.key === `doctor:${doctor.slug}`)?.value as Partial<Doctor> | undefined;
    return override ? { ...doctor, ...override, slug: doctor.slug, schedule: { ...doctor.schedule, ...override.schedule } } : doctor;
  });
  const extras = records.filter((record) => !doctors.some((doctor) => record.key === `doctor:${doctor.slug}`)).map((record) => record.value as unknown as Doctor);
  return [...base, ...extras];
}

export async function getSpecialties(): Promise<Specialty[]> {
  return mergeById(specialties, await loadGroup("specialty"), "specialty");
}

export async function getServices(): Promise<ServiceEntry[]> {
  return mergeById(services, await loadGroup("service"), "service");
}

export async function getGallery(): Promise<GalleryEntry[]> {
  return mergeById(gallery, await loadGroup("gallery"), "gallery");
}

export async function getSiteSettings(): Promise<SiteSettings> {
  try {
    const rows = await db.select().from(contentOverrides).where(eq(contentOverrides.key, "site:settings")).limit(1);
    return { ...defaultSettings, ...(rows[0]?.value || {}) } as SiteSettings;
  } catch {
    return defaultSettings;
  }
}

export async function saveOverride(key: string, value: Record<string, unknown>) {
  await db.insert(contentOverrides).values({ key, value, updatedAt: new Date() }).onConflictDoUpdate({
    target: contentOverrides.key,
    set: { value, updatedAt: new Date() },
  });
}
