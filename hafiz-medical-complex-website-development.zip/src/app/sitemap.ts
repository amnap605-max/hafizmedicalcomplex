import type { MetadataRoute } from "next";
import { getDoctors, getSpecialties } from "@/lib/content-db";
import { siteUrl } from "@/lib/seo";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [doctors, specialties] = await Promise.all([getDoctors(), getSpecialties()]);
  const staticPaths = ["/", "/about", "/doctors", "/specialties", "/appointments", "/services", "/gallery", "/patient-guide", "/contact"];
  return [...staticPaths, ...doctors.map((doctor) => `/doctors/${doctor.slug}`), ...specialties.map((specialty) => `/specialties/${specialty.slug}`)].map((path) => ({ url: `${siteUrl}${path}`, lastModified: new Date(), changeFrequency: path === "/" ? "weekly" : "monthly", priority: path === "/" ? 1 : path.includes("/doctors/") || path.includes("/specialties/") ? 0.6 : 0.8 }));
}
