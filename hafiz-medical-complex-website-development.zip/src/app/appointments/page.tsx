import { CalendarDays, CheckCircle2, Clock3, MessageCircle, Phone, ShieldCheck } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa6";
import { AppointmentForm } from "@/components/appointment-form";
import { PageHero } from "@/components/ui";
import { getDoctors, getSiteSettings, getSpecialties } from "@/lib/content-db";
import { phoneToHref } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Request an Appointment", "Request an appointment with a specialist at HAFIZ Medical Complex in Daska. Choose a doctor, visiting date and preferred time; requests await hospital confirmation.", "/appointments");

export default async function AppointmentsPage({ searchParams }: { searchParams: Promise<{ doctor?: string; specialty?: string }> }) {
  const params = await searchParams;
  const [doctors, specialties, settings] = await Promise.all([getDoctors(), getSpecialties(), getSiteSettings()]);
  const whatsapp = `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent("Hello HAFIZ Medical Complex, I would like to request an appointment. Please help me check doctor availability.")}`;
  return <><PageHero eyebrow="APPOINTMENT REQUEST" title="Let's Make Time for Your Health." description="Tell us which specialist you would like to see and when you prefer to visit. Our team will review your request and confirm availability separately." image="/images/reception-south-asian.jpg" imageAlt="Illustrative South Asian clinic reception; not HAFIZ Medical Complex" breadcrumbs={[{ label: "Appointments" }]} />
    <section className="section-space section-soft"><div className="container-site booking-layout"><AppointmentForm doctors={doctors} specialties={specialties} settings={settings} defaultDoctorSlug={params.doctor || ""} defaultSpecialtySlug={params.specialty || ""} /><div className="booking-side"><aside className="aside-card"><span className="mini-label">GOOD TO KNOW</span><h3 className="mt-2">How your request works</h3><div className="booking-side-list"><div><CalendarDays size={19} /><span>Choose a specialty, doctor and preferred visiting time.</span></div><div><ShieldCheck size={19} /><span>We save your request with a reference and <strong>pending</strong> status.</span></div><div><CheckCircle2 size={19} /><span>Hospital staff must approve availability before your appointment is confirmed.</span></div></div></aside><aside className="aside-card"><span className="mini-label">PREFER TO TALK?</span><h3 className="mt-2">We're here to help.</h3><p>Call the hospital or send a WhatsApp message to discuss visiting times directly.</p><a href={phoneToHref(settings.phone)} className="btn btn-outline"><Phone size={16} /> {settings.phone}</a><a href={whatsapp} target="_blank" rel="noopener noreferrer" className="btn btn-ghost"><FaWhatsapp size={18} /> WhatsApp Appointment</a></aside><div className="schedule-note"><Clock3 size={17} /> The hospital is advertised as open 24 hours. Individual doctor consultation schedules are separate and may change.</div></div></div></section>
  </>;
}
