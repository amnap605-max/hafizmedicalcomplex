import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight, CalendarDays, Check, HeartHandshake, Phone, Stethoscope } from "lucide-react";
import { CalloutCTA, DoctorCard, FAQList, PageHero, SectionHeading } from "@/components/ui";
import { getDoctors, getSpecialties } from "@/lib/content-db";
import { specialties, hospital } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";

export function generateStaticParams() { return specialties.map((specialty) => ({ slug: specialty.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const specialty = (await getSpecialties()).find((item) => item.slug === slug);
  return specialty ? pageMetadata(specialty.title, `${specialty.description} Learn about ${specialty.shortTitle.toLowerCase()} consultations, relevant doctors and appointment requests in Daska.`, `/specialties/${slug}`) : {};
}

export default async function SpecialtyDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [specialtiesList, doctors] = await Promise.all([getSpecialties(), getDoctors()]);
  const specialty = specialtiesList.find((item) => item.slug === slug);
  if (!specialty) notFound();
  const relevant = doctors.filter((doctor) => doctor.specialtySlugs.includes(slug));
  return <>
    <PageHero eyebrow="MEDICAL SPECIALTY" title={specialty.title} description={specialty.description} image={specialty.image} imageAlt={`Illustrative healthcare photography for ${specialty.title}; not HAFIZ staff or facilities`} breadcrumbs={[{ label: "Specialties", href: "/specialties" }, { label: specialty.title }]} />
    <section className="section-space"><div className="container-site split-content"><div className="profile-section"><span className="eyebrow"><span className="eyebrow-dot" /> ABOUT THIS SPECIALTY</span><h2 className="mt-3">Understanding {specialty.shortTitle.toLowerCase()} care</h2><p>{specialty.introduction}</p><div className="note-box mt-7">This information is for general education and does not replace a personal medical assessment. Please contact the hospital to confirm specific services and visiting schedules.</div></div><aside className="aside-card"><span className="mini-label">NEED AN APPOINTMENT?</span><h3 className="mt-2">Let's plan your visit.</h3><p>Choose a doctor from this specialty and share your preferred day and time. Our team will review the request.</p><Link href={`/appointments?specialty=${specialty.slug}`} className="btn btn-primary">Request Appointment <ArrowUpRight size={16} /></Link><a href={hospital.phoneHref} className="btn btn-outline"><Phone size={16} /> Call {hospital.phone}</a></aside></div></section>
    <section className="section-space section-soft"><div className="container-site"><SectionHeading eyebrow="COMMON CONCERNS" title="When this specialty may help." description="These are common topics you can discuss during a consultation. Your doctor will assess your individual situation." /><div className="bullet-grid">{specialty.conditions.map((condition) => <div className="bullet-item" key={condition}><span><Stethoscope size={14} /></span>{condition}</div>)}</div></div></section>
    <section className="section-space"><div className="container-site"><SectionHeading eyebrow="YOUR CONSULTATION" title="Care that starts with a conversation." description="A consultation is a chance to explain your concerns, ask questions and understand appropriate next steps." /><div className="simple-card-grid">{specialty.care.map((item, index) => <div className="simple-card" key={item}><span className="simple-card-icon">{index === 0 ? <HeartHandshake size={22} /> : index === 1 ? <Stethoscope size={22} /> : <CalendarDays size={22} />}</span><h3>{["Share your concern", "Understand your options", "Plan the next step"][index] || "Your care"}</h3><p>{item}</p></div>)}</div></div></section>
    <section className="section-space section-soft"><div className="container-site"><SectionHeading eyebrow="RELEVANT DOCTORS" title="Meet the specialists." description="See the consultation schedule on each profile. For unconfirmed visiting times, please call the hospital." action={{ label: "All doctors", href: "/doctors" }} /><div className="doctor-grid">{relevant.map((doctor) => <DoctorCard key={doctor.slug} doctor={doctor} />)}</div>{relevant.length === 0 && <p className="text-sm text-[#667B78]">Please contact the hospital for specialist availability.</p>}</div></section>
    <section className="section-space"><div className="container-site split-content"><div><SectionHeading eyebrow="QUESTIONS & ANSWERS" title={`FAQs about ${specialty.shortTitle.toLowerCase()}`} /><FAQList faqs={specialty.faqs} /></div><aside className="aside-card self-start"><span className="mini-label">A HELPFUL REMINDER</span><h3 className="mt-2">Before you visit</h3><p>Doctor schedules can change. An appointment request is not a confirmed booking until hospital staff approves it.</p><div className="mt-5 flex items-start gap-3 rounded-lg bg-[#E6F3EB] p-4 text-[12px] leading-6 text-[#42776e]"><Check size={17} className="mt-1 shrink-0" /> Have any previous reports or prescriptions? Bring them if available.</div><Link href="/patient-guide" className="text-link mt-5">Read the Patient Guide <ArrowUpRight size={16} /></Link></aside></div></section>
    <CalloutCTA title={`Take the next step with ${specialty.shortTitle.toLowerCase()} care.`} description="Tell us your preferred specialist and time. A member of the hospital team will review your appointment request." />
  </>;
}
