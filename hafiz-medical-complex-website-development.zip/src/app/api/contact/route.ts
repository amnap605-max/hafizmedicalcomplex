import { z } from "zod";
import { db } from "@/db";
import { contactEnquiries } from "@/db/schema";

export const dynamic = "force-dynamic";

const contactSchema = z.object({
  name: z.string().trim().min(2).max(160),
  email: z.email().max(200),
  phone: z.string().trim().regex(/^\+?[\d\s()-]{9,24}$/, "Enter a valid phone number."),
  subject: z.string().trim().min(3).max(200),
  message: z.string().trim().min(10).max(3000),
  website: z.string().max(0).optional(),
});

export async function POST(request: Request) {
  try {
    const parsed = contactSchema.safeParse(await request.json());
    if (!parsed.success) return Response.json({ error: "Please complete all fields with valid contact information." }, { status: 400 });
    const { name, email, phone, subject, message } = parsed.data;
    await db.insert(contactEnquiries).values({ name, email, phone, subject, message, status: "new" });
    return Response.json({ ok: true, message: "Your enquiry has been received." }, { status: 201 });
  } catch {
    return Response.json({ error: "We could not save your message right now. Please call or email the hospital instead." }, { status: 500 });
  }
}
