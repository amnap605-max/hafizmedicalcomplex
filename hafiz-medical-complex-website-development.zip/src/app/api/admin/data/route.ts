import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { appointmentRequests, contactEnquiries } from "@/db/schema";
import { isAdminAuthenticated } from "@/lib/admin-auth";
import { getDoctors, getGallery, getServices, getSiteSettings, getSpecialties, saveOverride } from "@/lib/content-db";

export const dynamic = "force-dynamic";

const slug = z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(120);
const nonEmpty = (max: number) => z.string().trim().min(1).max(max);
const list = z.array(nonEmpty(180)).max(40);
const httpsOrBlank = z.string().max(500).refine((value) => !value || value.startsWith("https://"), "Use a secure https URL.");
const scheduleSchema = z.object({ label: nonEmpty(150), days: z.array(z.number().int().min(0).max(6)).max(7), start: z.string().max(5), end: z.string().max(5), confirmed: z.boolean() });
const doctorSchema = z.object({ slug, name: nonEmpty(160), specialty: nonEmpty(160), specialtySlugs: z.array(slug).min(1).max(10), initials: nonEmpty(5), summary: nonEmpty(500), introduction: nonEmpty(3000), expertise: list, conditions: list, schedule: scheduleSchema, qualification: z.string().max(200).optional(), alsoKnownAs: z.string().max(200).optional(), featured: z.boolean().optional(), image: z.string().max(500).optional() });
const faqSchema = z.object({ question: nonEmpty(300), answer: nonEmpty(1500) });
const specialtySchema = z.object({ slug, title: nonEmpty(160), shortTitle: nonEmpty(80), description: nonEmpty(500), introduction: nonEmpty(3000), conditions: list, care: list, faqs: z.array(faqSchema).max(20), icon: nonEmpty(40), image: z.string().startsWith("/images/").max(250) });
const serviceSchema = z.object({ id: slug, title: nonEmpty(160), description: nonEmpty(1000), type: z.enum(["consultation", "diagnostic"]), status: z.enum(["listed", "unconfirmed"]), published: z.boolean(), specialtySlug: slug.optional() });
const gallerySchema = z.object({ id: slug, title: nonEmpty(160), category: nonEmpty(80), image: z.string().max(500).refine((value) => value.startsWith("/images/") || value.startsWith("https://"), "Use a local image path or secure image URL."), alt: nonEmpty(250), placeholder: z.boolean(), published: z.boolean() });
const settingsSchema = z.object({ phone: nonEmpty(30), helpline: nonEmpty(30), whatsapp: nonEmpty(20), email: z.email().max(200), address: nonEmpty(300), mapUrl: z.url().startsWith("https://").max(500), instagram: httpsOrBlank, facebook: httpsOrBlank, youtube: httpsOrBlank, tiktok: httpsOrBlank, linkedin: httpsOrBlank });

export async function GET() {
  if (!await isAdminAuthenticated()) return Response.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const [appointments, enquiries, doctors, specialties, services, gallery, settings] = await Promise.all([
      db.select().from(appointmentRequests).orderBy(desc(appointmentRequests.createdAt)).limit(300),
      db.select().from(contactEnquiries).orderBy(desc(contactEnquiries.createdAt)).limit(300),
      getDoctors(), getSpecialties(), getServices(), getGallery(), getSiteSettings(),
    ]);
    return Response.json({ appointments, enquiries, doctors, specialties, services, gallery, settings });
  } catch { return Response.json({ error: "Could not load staff data. Check database setup." }, { status: 500 }); }
}

export async function PATCH(request: Request) {
  if (!await isAdminAuthenticated()) return Response.json({ error: "Unauthorized" }, { status: 401 });
  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }
  try {
    if (body.kind === "appointment") {
      const parsed = z.object({ id: z.uuid(), status: z.enum(["pending", "approved", "rejected", "completed"]) }).safeParse(body);
      if (!parsed.success) return Response.json({ error: "Invalid appointment update." }, { status: 400 });
      await db.update(appointmentRequests).set({ status: parsed.data.status, updatedAt: new Date() }).where(eq(appointmentRequests.id, parsed.data.id));
      return Response.json({ ok: true });
    }
    if (body.kind === "enquiry") {
      const parsed = z.object({ id: z.uuid(), status: z.enum(["new", "in-progress", "resolved"]) }).safeParse(body);
      if (!parsed.success) return Response.json({ error: "Invalid enquiry update." }, { status: 400 });
      await db.update(contactEnquiries).set({ status: parsed.data.status }).where(eq(contactEnquiries.id, parsed.data.id));
      return Response.json({ ok: true });
    }
    if (body.kind === "doctor") {
      const parsed = doctorSchema.safeParse(body.item);
      if (!parsed.success) return Response.json({ error: "Please complete the doctor profile, specialty and schedule fields.", details: parsed.error.flatten().fieldErrors }, { status: 400 });
      const item = parsed.data;
      const specialties = await getSpecialties();
      if (!item.specialtySlugs.every((itemSlug) => specialties.some((specialty) => specialty.slug === itemSlug))) return Response.json({ error: "Choose a valid specialty for the doctor." }, { status: 400 });
      if (item.schedule.confirmed && (!item.schedule.days.length || !/^([01]\d|2[0-3]):[0-5]\d$/.test(item.schedule.start) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(item.schedule.end) || item.schedule.start >= item.schedule.end)) return Response.json({ error: "Published schedules need visiting days and a valid start/end time." }, { status: 400 });
      if (item.image && !item.image.startsWith("https://") && !item.image.startsWith("/images/")) return Response.json({ error: "Use a secure image URL or local image path." }, { status: 400 });
      await saveOverride(`doctor:${item.slug}`, item);
      return Response.json({ ok: true });
    }
    if (body.kind === "specialty") {
      const parsed = specialtySchema.safeParse(body.item);
      if (!parsed.success) return Response.json({ error: "Please complete the specialty content." }, { status: 400 });
      await saveOverride(`specialty:${parsed.data.slug}`, parsed.data);
      return Response.json({ ok: true });
    }
    if (body.kind === "service") {
      const parsed = serviceSchema.safeParse(body.item);
      if (!parsed.success) return Response.json({ error: "Please complete the service information." }, { status: 400 });
      await saveOverride(`service:${parsed.data.id}`, parsed.data);
      return Response.json({ ok: true });
    }
    if (body.kind === "gallery") {
      const parsed = gallerySchema.safeParse(body.item);
      if (!parsed.success) return Response.json({ error: "Please add a title, category, alt text and valid image URL." }, { status: 400 });
      await saveOverride(`gallery:${parsed.data.id}`, parsed.data);
      return Response.json({ ok: true });
    }
    if (body.kind === "settings") {
      const parsed = settingsSchema.safeParse(body.item);
      if (!parsed.success) return Response.json({ error: "Check the contact details and secure social URLs." }, { status: 400 });
      await saveOverride("site:settings", parsed.data);
      return Response.json({ ok: true });
    }
    return Response.json({ error: "Unknown update type." }, { status: 400 });
  } catch { return Response.json({ error: "Could not save changes. Please try again." }, { status: 500 }); }
}
