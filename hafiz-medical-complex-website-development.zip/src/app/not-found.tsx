import Link from "next/link";
import { ArrowRight, Home, Search } from "lucide-react";

export default function NotFound() {
  return <section className="section-space section-soft"><div className="container-site mx-auto max-w-[650px] py-14 text-center"><span className="eyebrow"><span className="eyebrow-dot" /> PAGE NOT FOUND</span><h1 className="mt-4 text-[44px] font-extrabold text-[#183D3D] md:text-[60px]">Let's find your way.</h1><p className="mx-auto mt-4 max-w-[470px] text-[14px] leading-7 text-[#667B78]">That page may have moved. You can return home, browse the doctor directory or contact the hospital for help.</p><div className="mt-7 flex flex-wrap justify-center gap-3"><Link href="/" className="btn btn-primary"><Home size={16} /> Back to Home</Link><Link href="/doctors" className="btn btn-outline"><Search size={16} /> Find a Doctor <ArrowRight size={16} /></Link></div></div></section>;
}
