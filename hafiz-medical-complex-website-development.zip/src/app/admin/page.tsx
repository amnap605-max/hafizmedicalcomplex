import type { Metadata } from "next";
import { AdminDashboard, AdminLogin } from "@/components/admin-panel";
import { adminConfigured, isAdminAuthenticated } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: { absolute: "Staff Access | HAFIZ Medical Complex" }, robots: { index: false, follow: false }, alternates: { canonical: "/admin" } };

export default async function AdminPage() {
  const authenticated = await isAdminAuthenticated();
  return authenticated ? <AdminDashboard /> : <AdminLogin configured={adminConfigured()} />;
}
