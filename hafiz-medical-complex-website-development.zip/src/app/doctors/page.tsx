import Link from "next/link";
import { ArrowUpRight, CalendarDays, Search, Stethoscope } from "lucide-react";
import { DoctorDirectory } from "@/components/doctor-directory";
import { CalloutCTA, PageHero, ScheduleNote, SectionHeading } from "@/components/ui";
import { getDoctors, getSpecialties } from "@/lib/content-db";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Our Doctors", "Find specialist doctors in Daska at HAFIZ Medical Complex. Search doctors by name, specialty or visiting day and request an appointment.", "/doctors");

export default async function DoctorsPage() {
  const [doctors, specialties] = await Promise.all([getDoctors(), getSpecialties()]);
  return <><PageHero eyebrow="OUR MEDICAL PROFESSIONALS" title="Find a Doctor Who Fits Your Needs." description="Explore individual profiles, consultation areas and published visiting schedules. Choose a specialist and send an appointment request in a few steps." image="/images/team-south-asian.jpg" imageAlt="Illustrative South Asian healthcare team; not HAFIZ staff" breadcrumbs={[{ label: "Our Doctors" }]} />
    <section className="section-space"><div className="container-site"><SectionHeading eyebrow="DOCTOR DIRECTORY" title="A specialist for your next step." description="Search by name or specialty, or select a visiting day. Unconfirmed schedules are marked clearly on each profile." /><DoctorDirectory doctors={doctors} specialties={specialties} /><div className="mt-8"><ScheduleNote /></div></div></section>
    <section className="section-space section-soft"><div className="container-site"><SectionHeading eyebrow="HOW IT WORKS" title="Finding care, made simple." /><div className="simple-card-grid"><div className="simple-card"><span className="simple-card-icon"><Search size={22} /></span><h3>Explore profiles</h3><p>Read about a doctor&apos;s consultation focus and commonly assessed conditions.</p></div><div className="simple-card"><span className="simple-card-icon"><CalendarDays size={22} /></span><h3>Check visiting hours</h3><p>See the published schedule, or contact the hospital when a doctor&apos;s hours are not confirmed.</p></div><div className="simple-card"><span className="simple-card-icon"><Stethoscope size={22} /></span><h3>Request a visit</h3><p>Send your preferred date and time. The hospital will review availability before confirming.</p></div></div><div className="mt-8 text-center"><Link href="/appointments" className="btn btn-primary">Request an Appointment <ArrowUpRight size={17} /></Link></div></div></section>
    <CalloutCTA />
  </>;
}
