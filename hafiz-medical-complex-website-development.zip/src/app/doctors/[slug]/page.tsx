import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowUpRight, CalendarDays, Clock3, Mail, MapPin, Phone, Stethoscope } from "lucide-react";
import { Breadcrumbs, CalloutCTA, DoctorAvatar, ScheduleNote, SectionHeading, SpecialtyCard } from "@/components/ui";
import { getDoctors, getSiteSettings, getSpecialties } from "@/lib/content-db";
import { doctors, phoneToHref } from "@/lib/content";
import { doctorStructuredData, pageMetadata } from "@/lib/seo";

export function generateStaticParams() { return doctors.map((doctor) => ({ slug: doctor.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const doctor = (await getDoctors()).find((item) => item.slug === slug);
  return doctor ? pageMetadata(doctor.name, `${doctor.name} — ${doctor.specialty} at HAFIZ Medical Complex, Daska. Explore consultation areas, visiting hours and request an appointment.`, `/doctors/${slug}`) : {};
}

export default async function DoctorProfilePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [allDoctors, specialties, settings] = await Promise.all([getDoctors(), getSpecialties(), getSiteSettings()]);
  const doctor = allDoctors.find((item) => item.slug === slug);
  if (!doctor) notFound();
  const related = specialties.filter((item) => doctor.specialtySlugs.includes(item.slug));
  const careImage = related[0]?.image || "/images/hero-south-asian.jpg";
  const schema = doctorStructuredData(doctor);
  return <>
    {schema && <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema).replace(/</g, "\\u003c") }} />}
    <section className="profile-hero"><div className="container-site"><Breadcrumbs items={[{ label: "Our Doctors", href: "/doctors" }, { label: doctor.name }]} /><div className="profile-layout"><div className="profile-visual"><div className="profile-context-image"><Image src={careImage} alt={`Illustrative South Asian care scene for ${doctor.specialty}; not a photograph of ${doctor.name}`} fill sizes="(max-width: 700px) 100vw, 28vw" className="object-cover" /><span>Illustrative care scene</span></div><div className="profile-visual-identity"><DoctorAvatar doctor={doctor} large /><div><strong>Personal profile</strong><span>{doctor.image ? "Hospital-provided portrait" : "Doctor photograph not yet provided"}</span></div></div></div><div className="profile-main"><span className="eyebrow"><span className="eyebrow-dot" /> DOCTOR PROFILE</span><h1>{doctor.name}</h1><p className="profile-specialty">{doctor.specialty}</p>{doctor.alsoKnownAs && <p className="!mb-2 text-[11px] font-semibold text-[#6a8393]">Also known as {doctor.alsoKnownAs}</p>}<p>{doctor.summary}</p><div className="profile-trust-row"><span><MapPin size={15} /> College Road, Daska</span><span><Clock3 size={15} /> Specialist consultation</span></div>{doctor.qualification && <span className="profile-qualification">{doctor.qualification}</span>}</div><div className="profile-schedule-card"><span className="mini-label">CONSULTATION SCHEDULE</span><h3>{doctor.schedule.confirmed ? "Visiting hours" : "Availability to confirm"}</h3><p>{doctor.schedule.label}</p><Link href={`/appointments?doctor=${doctor.slug}`} className="btn btn-primary">Request Appointment <ArrowUpRight size={16} /></Link><small>Request only · Pending hospital confirmation</small></div></div></div></section>
    <section className="section-space"><div className="container-site split-content"><div><div className="profile-section"><span className="eyebrow"><span className="eyebrow-dot" /> GET TO KNOW THE SPECIALIST</span><h2 className="mt-3">About {doctor.name}</h2><p>{doctor.introduction}</p></div><div className="profile-section mt-12"><h2>Areas of expertise</h2><div className="bullet-grid">{doctor.expertise.map((item) => <div className="bullet-item" key={item}><span><Stethoscope size={14} /></span>{item}</div>)}</div></div><div className="profile-section mt-12"><h2>Common concerns assessed</h2><p>These examples can help you decide whether this is the right consultation. A clinical assessment is always individual to the patient.</p><div className="bullet-grid">{doctor.conditions.map((item) => <div className="bullet-item" key={item}><span><Stethoscope size={14} /></span>{item}</div>)}</div></div></div><aside className="grid content-start gap-5"><div className="aside-card"><span className="mini-label">PLAN YOUR VISIT</span><h3 className="mt-2">Visiting schedule</h3><div className="flex items-start gap-3 rounded-lg bg-[#F2F8F3] p-4"><CalendarDays size={20} className="mt-0.5 shrink-0 text-[#087F78]" /><div><strong className="text-[12px] text-[#183D3D]">{doctor.schedule.label}</strong><p className="!mt-1 !mb-0 !text-[11px]">{doctor.schedule.confirmed ? "Published consultation hours. Please confirm before travelling." : "Please contact the hospital to confirm availability."}</p></div></div><Link href={`/appointments?doctor=${doctor.slug}`} className="btn btn-primary">Book Appointment <ArrowUpRight size={16} /></Link><a href={phoneToHref(settings.phone)} className="btn btn-outline"><Phone size={16} /> Call to Confirm</a></div><div className="aside-card"><span className="mini-label">HAFIZ MEDICAL COMPLEX</span><h3 className="mt-2">Here to help</h3><p>Have a question before you visit? The appointment team can help you check availability.</p><div className="profile-contact-row"><a href={phoneToHref(settings.phone)}><Phone size={15} /> {settings.phone}</a><a href={`mailto:${settings.email}`}><Mail size={15} /> Email hospital</a><Link href="/contact"><MapPin size={15} /> Find us in Daska</Link></div></div><ScheduleNote /></aside></div></section>
    <section className="section-space section-soft"><div className="container-site"><SectionHeading eyebrow="EXPLORE MORE" title={related.length === 1 ? "Related specialty" : "Related specialties"} description="Learn more about the consultation area and when it may be helpful to see a specialist." /><div className="specialty-grid">{related.map((specialty, index) => <SpecialtyCard key={specialty.slug} specialty={specialty} index={index} />)}</div></div></section>
    <CalloutCTA title={`Ready to request a visit with ${doctor.name}?`} description="Choose a preferred time and share a little about your concern. The hospital team will review your request before confirming an appointment." />
  </>;
}
